# study_computer

苏格拉底式家教工作区（从考研数学专案复制方法论后**已归零**），适用于操作系统等计算机类科目。

1. 用 Cursor **打开本文件夹**作为工作区根目录。
2. 编辑 `teacher_system/learner_profile.md`：科目、主教材路径（`materials/` 下）。
3. 将教材 Markdown 放入 `materials/`，更新 `teacher_system/progress.md` 的起点。
4. 规则与方法见根目录 `.cursorrules` 与 `teacher_system/system_prompt.md`。
